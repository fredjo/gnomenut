Track Database
==============

.. automodule:: xl.trackdb
   :members:

   .. autoclass:: TrackDB
      :members:

      .. automethod:: load_from_location(location=None)
