Collection
==========

.. automodule:: xl.collection
   :members:
   :show-inheritance:
