#include "../freebsd-g++/qplatformdefs.h"
